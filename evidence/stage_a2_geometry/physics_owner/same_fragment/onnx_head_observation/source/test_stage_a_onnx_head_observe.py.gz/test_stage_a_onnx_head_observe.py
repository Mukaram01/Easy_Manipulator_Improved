"""Diagnostic-only fixtures. Tests never create an ORT session or run a model."""
import sys
from pathlib import Path
import numpy as np
import onnx
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import stage_a_onnx_head_observe as observation


def tiny_model():
    h=onnx.helper
    # Minimal structural fixture, not an executed model or genuine detection.
    nodes=[h.make_node('Identity',['images'],[observation.TARGET],name='/network/roi_heads/Slice_12'),
           h.make_node('Identity',[observation.TARGET],['masks'],name='fixture')]
    return h.make_model(h.make_graph(nodes,'fixture',[h.make_tensor_value_info('images',1,['N',1,28,28])],
        [h.make_tensor_value_info(n,1,None) for n in ('boxes','labels','scores','masks')]),opset_imports=[h.make_opsetid('',17)])


def test_output_only_transform_preserves_every_original_field():
    original=tiny_model();diag=observation.expose(original)
    observation.validate_transform(original,diag)
    assert [v.name for v in diag.graph.output]==['boxes','labels','scores','masks',observation.TARGET]
    assert diag.graph.output[-1].type.tensor_type.elem_type==1
    dims=diag.graph.output[-1].type.tensor_type.shape.dim
    assert [d.dim_param if d.dim_param else d.dim_value for d in dims]==['N',1,28,28]
    assert len(original.graph.output)==4


@pytest.mark.parametrize('kind',['node','initializer','output_order','target','shape','dtype'])
def test_changed_computation_or_observation_contract_rejects(kind):
    original=tiny_model();diag=observation.expose(original)
    if kind=='node':diag.graph.node[0].op_type='Relu'
    if kind=='initializer':diag.graph.initializer.append(onnx.numpy_helper.from_array(np.array([1],dtype=np.float32),name='new'))
    if kind=='output_order':diag.graph.output[0].name='scores'
    if kind=='target':diag.graph.output[-1].name='wrong'
    if kind=='shape':diag.graph.output[-1].type.tensor_type.shape.dim[2].dim_value=30
    if kind=='dtype':diag.graph.output[-1].type.tensor_type.elem_type=11
    with pytest.raises(ValueError):observation.validate_transform(original,diag)


def test_class_selection_keeps_detection_order_and_exact_probability_bytes():
    a=np.zeros((3,2,28,28),dtype=np.float32)
    a[0,1]=.25;a[1,0]=.75;a[2,1]=np.nextafter(np.float32(.5),np.float32(1))
    labels=np.array([1,0,1],dtype=np.int64)
    selected=observation.select_class_fixture(a,labels)
    assert selected.shape==(3,1,28,28) and selected.nbytes==9408
    assert selected[:,0,0,0].tolist()==[.25,.75,float(np.nextafter(np.float32(.5),np.float32(1)))]
    assert a[1,0].tobytes()==selected[1,0].tobytes()


def test_bilinear_contributors_and_padding_have_literal_weights():
    head=np.ones((28,28),dtype=np.float32)
    c=observation.contributors(head,.25,1.5)
    assert c['value']==.25
    assert c['weights']==[.375,.125,.375,.125]
    assert c['probabilities']==[0.,1.,0.,1.]
    assert c['head_yx']==[None,[0,0],None,[1,0]]
    assert c['nearest_probability']==0.


def test_interpolation_can_cross_threshold_with_low_nearest_sample():
    head=np.zeros((28,28),dtype=np.float32);head[0,0]=.4;head[0,1]=1.
    c=observation.contributors(head,1.25,1.)
    assert c['nearest_probability']==pytest.approx(.4)
    assert c['value']==pytest.approx(.55)


def test_exported_output_byte_difference_is_noncomparable():
    before=[np.array([0.],dtype=np.float32).tobytes()]*4
    after=before.copy();after[0]=np.array([-0.],dtype=np.float32).tobytes()
    assert observation.comparability(before,before)['comparable']
    assert not observation.comparability(before,after)['comparable']


def test_exclusive_claim_survives_and_rejects_second_execution(tmp_path):
    observation.claim_once(tmp_path)
    with pytest.raises(FileExistsError):observation.claim_once(tmp_path)
