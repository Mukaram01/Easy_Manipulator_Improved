// Copyright 2022 Advanced Remanufacturing and Technology Centre
// Copyright 2022 ROS-Industrial Consortium Asia Pacific Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef EPD_UTILS_LIB__USECASE_CONFIG_HPP_
#define EPD_UTILS_LIB__USECASE_CONFIG_HPP_

#include <jsoncpp/json/json.h>
#include <string>
#include <vector>
#include <fstream>
#include "opencv2/opencv.hpp"
#include "epd_utils_lib/message_utils.hpp"


/*! \brief A collection of use-case filters, namely for parsing usecase_config.json,
Counting and Color-Matching usecaseMode.
 */
namespace EPD
{
const unsigned int CLASSIFICATION_MODE = 0;
const unsigned int COUNTING_MODE = 1;
const unsigned int COLOR_MATCHING_MODE = 2;
const unsigned int LOCALISATION_MODE = 3;
const unsigned int TRACKING_MODE = 4;
const unsigned int COLOR_HISTOGRAM_CORRELATION = 0;
const unsigned int COLOR_HISTOGRAM_CHI_SQUARE = 1;
const unsigned int COLOR_HISTOGRAM_INTERSECTION = 2;
const unsigned int COLOR_HISTOGRAM_BHATTACHARYYA = 3;

/*! \brief A Mutator function that takes the base inference results from a P3
inference engine and excludes any bounding boxes, classIndices and score
element that do not share the label of selected objects-to-be counted.
*/
inline void count(
  std::vector<std::array<int, 4>> & bboxes,
  std::vector<uint64_t> & classIndices,
  std::vector<float> & scores,
  std::vector<cv::Mat> & masks,
  std::vector<std::string> allClassNames,
  const std::vector<std::string> countClassNames)
{
  bool noMasksFound = false;
  if (masks.size() == 0) {
    noMasksFound = true;
  }

  // Set max number of object to detect to 1000.
  std::vector<std::array<int, 4>> local_bboxes;
  std::vector<uint64_t> local_classIndices;
  std::vector<float> local_scores;
  std::vector<cv::Mat> local_masks;
  /*Iterate through bbboxes, classIndices and allClassNames
  to count corresponding detected objects with the same labels.
  */
  for (size_t i = 0; i < bboxes.size(); ++i) {
    const auto & curBbox = bboxes[i];
    const uint64_t classIdx = classIndices[i];
    const float curScore = scores[i];
    cv::Mat curMask;
    if (!noMasksFound) {
      curMask = masks[i];
    }
    const std::string curLabel =
      classIdx >= allClassNames.size() ?
      std::to_string(classIdx) : allClassNames[classIdx];

    for (size_t j = 0; j < countClassNames.size(); j++) {
      std::string countLabel = countClassNames[j];
      if (curLabel.compare(countLabel) == 0) {
        local_bboxes.push_back(curBbox);
        local_classIndices.push_back(classIdx);
        local_scores.push_back(curScore);
        if (!noMasksFound) {
          local_masks.push_back(curMask);
        }
      }
    }
  }

  bboxes = local_bboxes;
  classIndices = local_classIndices;
  scores = local_scores;
  if (!noMasksFound) {
    masks = local_masks;
  }
}

/*! \brief A Mutator function that takes the base inference results from a P3
inference engine and excludes any bounding boxes, classIndices and score
element that is not similar enough to the template color..
*/
inline void matchColor(
  const cv::Mat & img,
  std::vector<std::array<int, 4>> & bboxes,
  std::vector<uint64_t> & classIndices,
  std::vector<float> & scores,
  std::vector<cv::Mat> & masks,
  std::vector<std::string> allClassNames,
  const std::string filepath_to_refcolor,
  const unsigned int histogram_metric,
  const float color_match_threshold = 0.8f)
{
  bool noMasksFound = false;
  if (masks.size() == 0) {
    noMasksFound = true;
  }
  cv::Mat ref_color_image = cv::imread(filepath_to_refcolor, cv::IMREAD_COLOR);
  cv::Mat hsv_base, hsv_test1;
  cv::cvtColor(ref_color_image, hsv_base, cv::COLOR_BGR2HSV);
  cv::Mat hist_base, hist_test1;
  int h_bins = 50, s_bins = 60;
  int histSize[] = {h_bins, s_bins};
  int channels[] = {0, 1};

  // hue varies from 0 to 179, saturation from 0 to 255
  float h_ranges[] = {0, 180};
  float s_ranges[] = {0, 256};
  const float * ranges[] = {h_ranges, s_ranges};
  cv::calcHist(&hsv_base, 1, channels, cv::Mat(), hist_base, 2, histSize, ranges, true, false);
  cv::normalize(hist_base, hist_base, 0, 1, cv::NORM_MINMAX, -1, cv::Mat());

  double base_base;
  cv::Mat croppedImage;
  std::vector<std::array<int, 4>> local_bboxes;
  std::vector<uint64_t> local_classIndices;
  std::vector<float> local_scores;
  std::vector<cv::Mat> local_masks;

  for (size_t i = 0; i < bboxes.size(); ++i) {
    const auto & curBbox = bboxes[i];
    const uint64_t classIdx = classIndices[i];
    const float curScore = scores[i];
    cv::Mat curMask;
    if (!noMasksFound) {
      curMask = masks[i];
    }
    const std::string curLabel =
      classIdx >= allClassNames.size() ?
      std::to_string(classIdx) : allClassNames[classIdx];

    // Clamp the bbox to the image boundaries before cropping to prevent
    // out-of-bounds access when a detection box slightly exceeds image dimensions.
    const int left = std::clamp(curBbox[0], 0, img.cols - 1);
    const int top = std::clamp(curBbox[1], 0, img.rows - 1);
    const int right = std::clamp(curBbox[2], left + 1, img.cols);
    const int bottom = std::clamp(curBbox[3], top + 1, img.rows);
    cv::Rect objectROI(cv::Point(left, top), cv::Point(right, bottom));
    if (objectROI.width <= 0 || objectROI.height <= 0) {
      continue;
    }
    croppedImage = img(objectROI);
    cv::cvtColor(croppedImage, hsv_test1, cv::COLOR_BGR2HSV);
    cv::calcHist(
      &hsv_test1, 1, channels, cv::Mat(),
      hist_test1, 2, histSize, ranges, true, false);
    cv::normalize(
      hist_test1, hist_test1, 0, 1,
      cv::NORM_MINMAX, -1, cv::Mat());

    base_base = compareHist(hist_base, hist_test1, histogram_metric);
    if (base_base > color_match_threshold) {
      local_bboxes.push_back(curBbox);
      local_classIndices.push_back(classIdx);
      local_scores.push_back(curScore);
      if (!noMasksFound) {
        local_masks.push_back(curMask);
      }
    }
  }

  bboxes = local_bboxes;
  classIndices = local_classIndices;
  scores = local_scores;
  if (!noMasksFound) {
    masks = local_masks;
  }
}

/*! \brief A Mutator function that takes the base inference results from a P3
inference engine and excludes any bounding boxes, classIndices and score
element based on a selected use-case filter.
*/
inline void activateUseCase(
  const cv::Mat & img,
  std::vector<std::array<int, 4>> & bboxes,
  std::vector<uint64_t> & classIndices,
  std::vector<float> & scores,
  std::vector<cv::Mat> & masks,
  std::vector<std::string> allClassNames,
  const unsigned int useCaseMode,
  const std::vector<std::string> countClassNames,
  const std::string filepath_to_refcolor,
  const unsigned int histogram_metric,
  const float color_match_threshold = 0.8f)
{
  // If default CLASSIFICATION_MODE is selected, do not alter anything and return.
  if (useCaseMode == EPD::CLASSIFICATION_MODE) {
    return;
  } else if (useCaseMode == EPD::COUNTING_MODE) {
    EPD::count(bboxes, classIndices, scores, masks, allClassNames, countClassNames);
  } else if (useCaseMode == EPD::COLOR_MATCHING_MODE) {
    EPD::matchColor(
      img, bboxes, classIndices, scores, masks, allClassNames,
      filepath_to_refcolor, histogram_metric, color_match_threshold);
  } else {
    throw std::runtime_error(
      "activateUseCase called with unsupported mode " + std::to_string(useCaseMode) +
      ". This function only accepts detection use-case modes: "
      "CLASSIFICATION_MODE(0), COUNTING_MODE(1), or COLOR_MATCHING_MODE(2). "
      "LOCALISATION_MODE(3) and TRACKING_MODE(4) use separate inference paths.");
  }
}

}  // namespace EPD

#endif  // EPD_UTILS_LIB__USECASE_CONFIG_HPP_
